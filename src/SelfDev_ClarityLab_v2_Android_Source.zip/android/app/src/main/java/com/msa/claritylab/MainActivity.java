package com.msa.claritylab;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

/**
 * Strictly offline, single-asset WebView. No INTERNET permission is requested.
 * A local virtual HTTPS origin makes browser storage usable without file:// access.
 */
public final class MainActivity extends Activity {
    private static final String HOST = "appassets.androidplatform.net";
    private static final String APP_URL = "https://" + HOST + "/assets/index.html";
    private static final int EXPORT_REQUEST = 41;
    private static final int IMPORT_REQUEST = 42;
    private static final int MAX_BACKUP_BYTES = 1024 * 1024;
    private WebView webView;
    private String pendingExport;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(8, 13, 25));
        getWindow().setNavigationBarColor(Color.rgb(8, 13, 25));
        FrameLayout frame = new FrameLayout(this);
        webView = new WebView(this);
        frame.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        setContentView(frame);
        if (Build.VERSION.SDK_INT >= 35) {
            frame.setOnApplyWindowInsetsListener((v, insets) -> {
                int top = insets.getInsets(WindowInsets.Type.statusBars() | WindowInsets.Type.displayCutout()).top;
                int bottom = insets.getInsets(WindowInsets.Type.navigationBars()).bottom;
                frame.setPadding(0, top, 0, bottom);
                return insets;
            });
            frame.requestApplyInsets();
        }

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setGeolocationEnabled(false);
        settings.setBlockNetworkLoads(true);
        settings.setMediaPlaybackRequiresUserGesture(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) settings.setSafeBrowsingEnabled(true);
        webView.addJavascriptInterface(new BackupBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient() {
            private boolean isTrusted(Uri uri) {
                return uri != null && "https".equals(uri.getScheme()) && HOST.equals(uri.getHost())
                    && "/assets/index.html".equals(uri.getPath());
            }
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !isTrusted(request.getUrl());
            }
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                if (!isTrusted(request.getUrl())) return denied();
                try {
                    InputStream stream = getAssets().open("index.html");
                    WebResourceResponse response = new WebResourceResponse("text/html", "UTF-8", stream);
                    Map<String, String> headers = new HashMap<>();
                    headers.put("Cache-Control", "no-store");
                    headers.put("X-Content-Type-Options", "nosniff");
                    response.setResponseHeaders(headers);
                    return response;
                } catch (IOException ex) {
                    return denied();
                }
            }
            private WebResourceResponse denied() {
                WebResourceResponse response = new WebResourceResponse("text/plain", "UTF-8",
                    new java.io.ByteArrayInputStream(new byte[0]));
                response.setStatusCodeAndReasonPhrase(404, "Not Found");
                return response;
            }
        });
        webView.loadUrl(APP_URL);
    }

    public final class BackupBridge {
        @JavascriptInterface
        public void exportJson(String json) {
            if (json == null || json.getBytes(StandardCharsets.UTF_8).length > MAX_BACKUP_BYTES) {
                notifyWeb("Backup exceeds the 1 MB limit.");
                return;
            }
            runOnUiThread(() -> {
                pendingExport = json;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, "clarity-lab-backup.json");
                startActivityForResult(intent, EXPORT_REQUEST);
            });
        }
        @JavascriptInterface
        public void importJson() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                startActivityForResult(intent, IMPORT_REQUEST);
            });
        }
    }

    private void notifyWeb(String text) {
        final String safe = text.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ").replace("\r", " ");
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript("window.__clarityBridgeMessage('" + safe + "')", null);
        });
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent result) {
        super.onActivityResult(requestCode, resultCode, result);
        if (resultCode != RESULT_OK || result == null || result.getData() == null) {
            if (requestCode == EXPORT_REQUEST) pendingExport = null;
            return;
        }
        Uri uri = result.getData();
        try {
            if (requestCode == EXPORT_REQUEST) {
                String content = pendingExport;
                pendingExport = null;
                if (content == null) throw new IOException("No pending backup");
                try (OutputStream out = getContentResolver().openOutputStream(uri, "w")) {
                    if (out == null) throw new IOException("Cannot open backup destination");
                    out.write(content.getBytes(StandardCharsets.UTF_8));
                    out.flush();
                }
                notifyWeb("Backup saved to the location you selected.");
            } else if (requestCode == IMPORT_REQUEST) {
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    if (in == null) throw new IOException("Cannot read selected file");
                    ByteArrayOutputStream out = new ByteArrayOutputStream();
                    byte[] buffer = new byte[8192];
                    int count;
                    while ((count = in.read(buffer)) != -1) {
                        if (out.size() + count > MAX_BACKUP_BYTES) throw new IOException("Backup exceeds 1 MB limit");
                        out.write(buffer, 0, count);
                    }
                    String encoded = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
                    webView.evaluateJavascript("window.__clarityImportBase64('" + encoded + "')", null);
                }
            }
        } catch (Exception err) {
            notifyWeb("Unable to access backup file: " + err.getClass().getSimpleName());
        }
    }

    @Override
    protected void onDestroy() {
        pendingExport = null;
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidBridge");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
