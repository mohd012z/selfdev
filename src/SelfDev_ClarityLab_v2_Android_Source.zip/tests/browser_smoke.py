"""Chromium DOM test via set_content; hosted navigation is blocked by policy."""
from pathlib import Path
from playwright.sync_api import sync_playwright
HTML=Path(__file__).resolve().parents[1].joinpath('Clarity_Lab_SelfDev_Offline.html').read_text()
ROOT=Path(__file__).resolve().parents[1]
ERRORS=[]
FAKE_STORAGE='''() => {
 const memory = {};
 Object.defineProperty(window,'localStorage',{
   configurable:true,
   value:{ getItem:k=>Object.prototype.hasOwnProperty.call(memory,k)?memory[k]:null,
           setItem:(k,v)=>{memory[k]=String(v)}, removeItem:k=>{delete memory[k]} }
 });
}'''
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu'])
 for width,height,device in [(1440,900,'desktop'),(390,844,'mobile')]:
  context=browser.new_context(viewport={'width':width,'height':height},accept_downloads=True)
  page=context.new_page()
  page.on('pageerror',lambda e:ERRORS.append('JS '+str(e)))
  page.evaluate(FAKE_STORAGE)
  page.set_content(HTML,wait_until='load')
  assert page.locator('#main').count()==1,'Main missing'
  assert page.locator('.hero h1').count()==1
  print(device,'initial',page.locator('.hero h1').inner_text().replace('\n',' '))
  page.screenshot(path=str(ROOT/f'{device}-final.png'),full_page=True)
  assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth'),device+' horizontal overflow'
  page.locator('[data-action=nav][data-page=learn]:visible').first.click()
  assert page.locator('.lesson-card').count()==18
  page.locator('.lesson-card button').first.click()
  assert 'Lead with the point' in page.locator('.lesson-detail h1').inner_text()
  page.locator('[data-action=toggle-lesson]').click()
  assert page.locator('[data-action=toggle-lesson]').inner_text().startswith('✓ Mark as not completed')
  page.locator('[data-action=back-lessons]').click()
  page.locator('#lesson-search').fill('jargon')
  assert page.locator('.lesson-card').count()==1,'search filter broken'
  page.locator('[data-action=nav][data-page=quiz]:visible').first.click()
  page.locator('input[name=current-answer][value="4"]').check(force=True)
  page.locator('[data-action=quiz-next]').click()
  page.locator('[data-action=quiz-results]').click()
  assert page.locator('.result-score').count()==6
  page.locator('[data-action=nav][data-page=practice]:visible').first.click()
  page.locator('#practice-answer').fill('Because we want a clear point, I suggest giving one specific example so that each listener can follow the explanation. For example, explain the main idea first.')
  page.locator('[data-action=feedback]').click()
  assert page.locator('.feedback').count()==1
  assert 'cannot measure' in page.locator('.feedback').inner_text()
  page.locator('[data-action=nav][data-page=journal]:visible').first.click()
  page.locator('#journal-text').fill('<script>alert(1)</script> is a literal journal entry')
  page.locator('[data-action=journal-save]').click()
  assert page.locator('.journal-item').count()==1
  assert page.locator('.journal-item script').count()==0,'XSS risk'
  assert '<script>' in page.locator('.journal-item p').inner_text()
  page.locator('[data-action=nav][data-page=settings]:visible').first.click()
  assert 'Saved on this device' in page.locator('#save-chip').inner_text()
  with page.expect_download(timeout=10000) as dl:
   page.locator('[data-action=export]').click()
  download=dl.value
  assert download.suggested_filename=='clarity-lab-backup.json'
  saved=download.path()
  assert Path(saved).stat().st_size>0
  print(device,'backup bytes',Path(saved).stat().st_size)
  page.locator('[data-action=theme]').first.click()
  assert page.locator('html').get_attribute('data-theme')=='light'
  page.locator('[data-action=large-text]').click()
  assert page.evaluate("document.documentElement.classList.contains('large-text')")
  page.screenshot(path=str(ROOT/f'{device}-settings.png'),full_page=True)
  # DOM lifecycle rebuild retains memory storage shim; check stored snapshot has a journal note.
  state=page.evaluate("localStorage.getItem('selfdev.claritylab.v2')")
  assert '<script>' in state and '"completed":["cl-1"]' in state
  context.close()
 browser.close()
if ERRORS:
 print(ERRORS)
 raise SystemExit(1)
print('BROWSER CHECKS: PASS (2 viewports; storage backed by mock due restricted navigation)')
