"""Adversarial and narrow-screen browser checks with explicit mocked storage."""
from pathlib import Path
import json
from playwright.sync_api import sync_playwright
SRC=Path(__file__).resolve().parents[1].joinpath('Clarity_Lab_SelfDev_Offline.html').read_text()
STUB='''() => {const db={};Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>db[k]??null,setItem:(k,v)=>db[k]=String(v)}})}'''
checks=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 for w in [320,360,390,768,1024,1440]:
  page=b.new_page(viewport={'width':w,'height':780})
  page.evaluate(STUB)
  page.set_content(SRC)
  no_overflow=page.evaluate('document.documentElement.scrollWidth<=innerWidth')
  assert no_overflow,f'overflow at {w}'
  assert page.locator('#notice').is_hidden(),f'empty notice shown at {w}'
  page.locator('[data-action=nav][data-page=quiz]:visible').first.click()
  rating=page.locator('input[name=current-answer][value="3"]')
  rating.check(force=True)
  assert json.loads(page.evaluate("localStorage.getItem('selfdev.claritylab.v2')"))['answers']['q01']==3
  page.locator('[data-action=quiz-skip]').click()
  page.locator('[data-action=quiz-prev]').click()
  assert page.locator('input[name=current-answer]:checked').count()==0
  assert 'q01' not in json.loads(page.evaluate("localStorage.getItem('selfdev.claritylab.v2')"))['answers']
  checks.append(f'viewport_{w}')
  page.close()
 # Import invalid JSON and malicious content; old data must survive.
 page=b.new_page(viewport={'width':390,'height':780})
 page.evaluate(STUB);page.set_content(SRC)
 page.locator('[data-action=nav][data-page=journal]:visible').first.click()
 page.locator('#journal-text').fill('A private note')
 page.locator('[data-action=journal-save]').click()
 page.locator('[data-action=nav][data-page=settings]:visible').first.click()
 inp=page.locator('#backup-input')
 inp.set_input_files({'name':'invalid.json','mimeType':'application/json','buffer':b'{not json'})
 assert page.locator('#notice').is_visible()
 state=json.loads(page.evaluate("localStorage.getItem('selfdev.claritylab.v2')"))
 assert len(state['journal'])==1
 checks.append('corrupt_json_keeps_records')
 malicious={'schema':1,'answers':{'q01':6,'q02':4},'completed':['cl-1','x','cl-1'], 'practiced':['p1','p1'], 'journal':[{'id':'<svg/onload=alert(1)>','text':'<img src=x onerror=alert(1)>','created':'2026-11-14T00:00:00Z'}],'theme':'light','unused':'sneaky'}
 page.once('dialog',lambda d:d.accept())
 inp.set_input_files({'name':'malicious.json','mimeType':'application/json','buffer':json.dumps(malicious).encode()})
 page.locator('[data-action=nav][data-page=journal]:visible').first.click()
 assert page.locator('.journal-item img').count()==0
 assert '<img' in page.locator('.journal-item p').inner_text()
 saved=json.loads(page.evaluate("localStorage.getItem('selfdev.claritylab.v2')"))
 assert saved['completed']==['cl-1'] and saved['answers']=={'q02':4} and 'unused' not in saved
 checks.append('legacy_import_sanitization_and_escaped_html')
 page.locator('[data-action=nav][data-page=settings]:visible').first.click()
 page.once('dialog',lambda d:d.accept())
 page.locator('[data-action=erase]').click()
 saved=json.loads(page.evaluate("localStorage.getItem('selfdev.claritylab.v2')"))
 assert saved['completed']==[] and saved['journal']==[] and saved['answers']=={}
 checks.append('erase_with_confirmation')
 page.close();b.close()
print('BROWSER EDGE CHECKS:',len(checks), 'passed:',', '.join(checks))
