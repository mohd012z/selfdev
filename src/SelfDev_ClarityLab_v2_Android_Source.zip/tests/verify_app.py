#!/usr/bin/env python3
"""Deterministic offline checks: evidence about source, not APK runtime behavior."""
from pathlib import Path
import json,hashlib,re,unittest,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[1]
HTML=(ROOT/'Clarity_Lab_SelfDev_Offline.html').read_text(encoding='utf-8')
JS=(ROOT/'web/extracted.js').read_text(encoding='utf-8')
DATA=json.loads((ROOT/'web/curriculum.json').read_text(encoding='utf-8'))
JAVA=(ROOT/'android/app/src/main/java/com/msa/claritylab/MainActivity.java').read_text(encoding='utf-8')
MANIFEST=(ROOT/'android/app/src/main/AndroidManifest.xml').read_text(encoding='utf-8')
WORKFLOW=(ROOT/'.github/workflows/android-apk.yml').read_text(encoding='utf-8')
class OfflineSourceTests(unittest.TestCase):
 def test_01_single_html_has_one_script(self):
  self.assertEqual(len(re.findall(r'<script\b',HTML,re.I)),1)
  self.assertEqual(len(re.findall(r'<style\b',HTML,re.I)),1)
 def test_02_no_external_assets(self):
  self.assertNotRegex(HTML,r'<(?:script|img|link)[^>]+(?:src|href)=')
  self.assertNotRegex(HTML,r'(?i)https?://(?!appassets\.androidplatform\.net)')
 def test_03_no_fetch_or_external_connections(self):
  self.assertNotRegex(JS,r'\b(?:fetch|XMLHttpRequest|sendBeacon|WebSocket|EventSource)\s*\(')
  self.assertIn("connect-src 'none'",HTML)
 def test_04_orig_curriculum_counts(self):
  self.assertEqual((len(DATA['SKILLS']),len(DATA['LESSONS']),len(DATA['EXERCISES']),len(DATA['QUESTIONS'])),(6,18,12,26))
 def test_05_unique_ids(self):
  for key in ['SKILLS','LESSONS','EXERCISES','QUESTIONS']:
   ids=[e['id'] for e in DATA[key]]
   self.assertEqual(len(ids),len(set(ids)),key)
 def test_06_skill_mappings(self):
  valid={x['id'] for x in DATA['SKILLS']}
  for key in ['LESSONS','EXERCISES','QUESTIONS']:
   self.assertTrue(all(x['skill'] in valid for x in DATA[key]))
 def test_07_no_missing_content(self):
  for lesson in DATA['LESSONS']:
   self.assertTrue(len(lesson['steps'])>=3 and all(lesson.get(k) for k in ['title','intro','example','reflection']))
 def test_08_escaped_user_text(self):
  self.assertIn('function sanitize(raw)',JS)
  self.assertIn('const esc=',JS)
  self.assertIn('data.journal.map',JS)
  self.assertIn('${esc(x.text)}',JS)
  self.assertIn('MAX_BACKUP_BYTES',JAVA)
 def test_09_backup_validation(self):
  self.assertIn('1024*1024',JS)
  self.assertIn('allowedQuestions.has(k)',JS)
  self.assertIn('allowedLessons.has(x)',JS)
  self.assertIn("confirm('Replace all current learning records",JS)
 def test_10_no_default_microphone(self):
  self.assertNotIn('getUserMedia',JS)
  self.assertNotIn('MediaRecorder',JS)
  for p in ['android.permission.INTERNET','android.permission.RECORD_AUDIO','android.permission.CAMERA','android.permission.READ_CONTACTS']:
   self.assertNotIn(p,MANIFEST)
 def test_11_android_asset_exact_copy(self):
  self.assertEqual((ROOT/'android/app/src/main/assets/index.html').read_bytes(),(ROOT/'Clarity_Lab_SelfDev_Offline.html').read_bytes())
 def test_12_native_origin_lock(self):
  for term in ['setBlockNetworkLoads(true)','setAllowFileAccess(false)','setAllowUniversalAccessFromFileURLs(false)','HOST.equals(uri.getHost())','setJavaScriptCanOpenWindowsAutomatically(false)','WebResourceResponse','"/assets/index.html".equals(uri.getPath())']:
   self.assertIn(term,JAVA)
 def test_13_device_file_picker_is_scoped(self):
  self.assertIn('Intent.ACTION_CREATE_DOCUMENT',JAVA)
  self.assertIn('Intent.ACTION_OPEN_DOCUMENT',JAVA)
  self.assertIn('getContentResolver().openOutputStream',JAVA)
  self.assertIn('getContentResolver().openInputStream',JAVA)
 def test_14_apk_package_id(self):
  self.assertIn('applicationId = "com.msa.claritylab"',(ROOT/'android/app/build.gradle.kts').read_text())
  self.assertIn('versionName = "2.0"',(ROOT/'android/app/build.gradle.kts').read_text())
 def test_15_manifest_security(self):
  ET.fromstring(MANIFEST)
  self.assertIn('android:allowBackup="false"',MANIFEST)
  self.assertIn('android:usesCleartextTraffic="false"',MANIFEST)
 def test_16_manual_only_ci(self):
  self.assertIn('workflow_dispatch:',WORKFLOW)
  self.assertNotRegex(WORKFLOW,r'(?m)^\s{2}(push|pull_request|schedule):')
  self.assertIn('github.event.repository.private == false',WORKFLOW)
  self.assertIn('selfdev-clarity-lab-debug-apk',WORKFLOW)
 def test_17_build_verifies_signature(self):
  self.assertIn('apksigner',WORKFLOW)
  self.assertIn('sha256sum',WORKFLOW)
  self.assertIn('unzip -t',WORKFLOW)
 def test_18_complete_initial_render(self):
  for term in ['function overview()','function lessons()','function practice()','function quiz()','function journal()','function settings()','function about()','function render()']:
   self.assertIn(term,JS)
 def test_19_responsive_accessibility(self):
  self.assertIn('@media(max-width:570px)',HTML)
  self.assertIn('prefers-reduced-motion:reduce',HTML)
  self.assertIn('aria-label',HTML)
  self.assertIn('class="skip"',JS)
 def test_20_no_licensing_or_subscription_hooks(self):
  self.assertNotRegex(JS,r'(?i)\b(?:stripe|revenuecat|purchaseToken|billingClient)\b')
 def test_21_deterministic_embedded_payload(self):
  self.assertNotIn('__DATA__',HTML)
  self.assertIn('Lead with the point',HTML)
  self.assertGreater(len(HTML),50000)
 def test_22_provenance(self):
  self.assertEqual(hashlib.sha256(HTML.encode()).hexdigest(),hashlib.sha256((ROOT/'android/app/src/main/assets/index.html').read_bytes()).hexdigest())
if __name__=='__main__':
 unittest.main(verbosity=2)
