from pathlib import Path
import json
base=Path(__file__).parent
style=(base/'web/styles.css').read_text(encoding='utf-8')
script=(base/'web/app.js').read_text(encoding='utf-8')
data=json.loads((base/'web/curriculum.json').read_text(encoding='utf-8'))
data_js=json.dumps(data,ensure_ascii=False,separators=(',',':')).replace('<','\\u003c').replace('>','\\u003e').replace('&','\\u0026')
assert script.count('__DATA__')==1
script=script.replace('__DATA__',data_js)
assert '</script' not in script.lower()
assert '</style' not in style.lower()
html=f'''<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#080d19">
<meta name="color-scheme" content="dark light">
<meta name="description" content="Clarity Lab — free, offline, original communication learning. No accounts, payment, or tracking.">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data:; media-src blob:; connect-src 'none'; frame-src 'none'; object-src 'none'; base-uri 'none'; form-action 'none'">
<title>Clarity Lab | Personal Communication Studio</title>
<style>
{style}
</style>
</head>
<body>
<div id="app"><div role="status" style="padding:32px;font:16px system-ui">Opening Clarity Lab…</div></div>
<noscript><div style="padding:2rem">JavaScript is required for interactive features. This file contains all code and lessons locally.</div></noscript>
<script>
{script}
</script>
</body>
</html>
'''
path=base/'Clarity_Lab_SelfDev_Offline.html'
path.write_text(html,encoding='utf-8')
(base/'android/app/src/main/assets/index.html').write_text(html,encoding='utf-8')
(base/'web/extracted.js').write_text(script,encoding='utf-8')
print('HTML built:',path,'bytes:',path.stat().st_size,'embedded lessons',len(data['LESSONS']))
