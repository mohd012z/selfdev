# SelfDev Clarity Lab v2 — Deep-dive Weakness and Improvement Report

This report separates verified code and local test evidence from runtime facts not checked on an Android device.

| Finding in previous package | Risk | Mitigation in v2 | Verification |
|---|---|---|---|
| `index.html` required vendor React, external CSS, module scripts, manifest and cache worker | A single attachment was not independently usable | One self-contained HTML with CSS, JS, all content | Single-file parser and embedded-data cardinality tests |
| Previous app stored IndexedDB records for a different origin/app shell | User may assume installed replacement preserves data | v2 supports v1 JSON import; no silent cross-origin migration claims | Sanitizer accepts only schema v1/v2; manual browser tests |
| `file://` browsers can disable storage | Lost progress on reload | Visible 'memory only' warning, JSON backup, Android virtual HTTPS origin | Browser `set_content` confirms fallback; Android not run |
| Generic Capacitor dependencies and Android SDK required to build | More moving parts and download failures | Dependency-light Java WebView wrapper, no external UI runtime | Android source audit passed; compilation blocked without SDK |
| Backup downloads from WebView `blob:` may fail on mobile | Users cannot back up private records | Android SAF import/export native bridge | Static bridge checks; device runtime pending |
| Browser/app permissions can surprise users | Privacy and trust | No INTERNET, RECORD_AUDIO, camera, contacts or location permissions; block network | Manifest and WebSettings checked |
| Imported backups could include malicious or malformed values | Injection, corrupt state | 1 MB cap, strict schema, whitelist IDs, HTML escaping, preview/confirm before overwriting | Browser and Python edge tests |
| Text feedback could be mistaken for AI understanding | Misleading claims | Exact heuristic description and no personal grades | Code inspection |
| Mobile visual layout not previously exercised in real browser | Overflow/unusable controls | Responsive fixed bottom nav and small-screen design | Chromium `set_content` screenshots and layout tests |
| No reproducible APK signing evidence | Cannot know built file is valid | Manual workflow validates ZIP, package ID, signature and SHA-256 | Workflow inspected; artifact not available yet |

**Unverified:** an installable APK, actual device storage persistence, Android SAF save/restore, layout below screen insets, and offline launch on a physical Android device. These require Android SDK/CI and device testing.

**No data sent:** no deployment, billing, external services, or repository write was executed as part of local creation.
