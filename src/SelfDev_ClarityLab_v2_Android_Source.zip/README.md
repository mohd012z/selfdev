# SelfDev — Clarity Lab v2

**Clarity Lab** is an original, age-appropriate, private communication-skills learning studio. It is not affiliated with RiseGuide and does not copy or provide access to its paid content.

## Run the web app

Open `Clarity_Lab_SelfDev_Offline.html` in a browser. It contains all CSS, JavaScript, 26 reflection questions, 18 lessons, and 12 exercises in **one HTML file**, with no network dependencies. It attempts to save to `localStorage`, and warns if the current browser blocks storage for local files. No account or payment is needed.

## Android app

A minimal Java Android app embeds the **same** HTML in `android/app/src/main/assets/index.html`, intercepts a virtual HTTPS origin, and blocks network requests. It requests **no Android permissions**. The optional backup export/import actions use the Android system document picker (Storage Access Framework). Data remains in the app's WebView storage unless explicitly exported. The debug APK is a development build; it is not a production release or Play Store build.

- Application ID: `com.msa.claritylab`
- Display name: `Clarity Lab`
- Minimum Android: 8.0 / API 26
- Target: API 35; compile SDK 36
- Android Gradle Plugin: `8.13.2`; Gradle `8.13`; Java `17`
- Dependencies: Android Gradle Plugin only; no AndroidX, ads, analytics, subscriptions, or external AI SDK.

### Local build with Android SDK + Gradle

From the repository root:

```bash
python3 tests/verify_app.py
cd android
gradle --no-daemon :app:assembleDebug
```

Expected output (after an actual successful build): `android/app/build/outputs/apk/debug/app-debug.apk`.

### GitHub Actions build

In a **public** GitHub repository, open Actions → **SelfDev Clarity Lab APK (manual only)** → Run workflow. This project deliberately contains no push, pull-request, schedule, deployment, release or publishing trigger. Verify and download the `selfdev-clarity-lab-debug-apk` artifact if the run succeeds. No workflow was dispatched by generating this project.

## Controls and limitations

- All source is included and can run without third-party web scripts or online requests.
- Browser local storage depends on browser origin/storage settings. If your file browser blocks it, use the Android APK or another browser and the backup/export action.
- Android system file picker requests user selection; it does not require broad storage permissions.
- A text-only heuristic coach provides suggestions based on patterns; it cannot measure communication ability, personality, emotions, speech or articulation.
- CSP permits inline JS/CSS because one-file delivery was explicitly requested. This is less strict than a multi-file nonce/hash CSP; user-authored content is HTML-escaped before rendering.
- The in-browser backup is a **plain JSON** file. Store it privately.
- Not independently verified on a physical Android device until an actual APK is built and tested there.
- No secrets, payments, production deployments, or third-party accounts.

## Verification

`tests/verify_app.py` checks single-file structure, content cardinality, unsafe network/permission patterns, app metadata, Java bridge file bounds, matching APK asset, and build workflow triggers. `tests/browser_smoke.py` exercises Chromium DOM rendering and interactions where supported; local navigation is blocked in some hosted environments, so its `set_content` fallback cannot validate persistent origin-specific storage.

## Source structure

```
Clarity_Lab_SelfDev_Offline.html      # final one-file web app
android/app/src/main/assets/index.html # byte-for-byte same HTML for APK
android/app/src/main/java/...        # offline WebView + SAF backup bridge
android/app/build.gradle.kts         # standalone Android app build
.github/workflows/android-apk.yml    # manual-only debug APK pipeline
web/                                 # authoring inputs for re-generating one HTML
build_single.py                      # deterministic HTML assembler
tests/                               # static/browser validation
```
